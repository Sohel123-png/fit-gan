document.addEventListener('DOMContentLoaded', async () => {
    const canvas = document.getElementById('progressChart');
    canvas.style.opacity = '0'; // Start invisible
    setTimeout(() => {
        canvas.style.transition = 'opacity 0.5s ease-in';
        canvas.style.opacity = '1'; // Fade in
    }, 500); // Delay to align with card animations

    // Fetch tracker data
    const response = await fetch('/progress_data');
    const data = await response.json();

    // Prepare chart data
    const labels = data.map(entry => entry.date);
    const scores = data.map(entry => entry.score);
    const sleep = data.map(entry => entry.sleep_hours);
    const water = data.map(entry => entry.water_intake);

    // Render chart
    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Score',
                    data: scores,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    fill: false
                },
                {
                    label: 'Sleep (hours)',
                    data: sleep,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    fill: false
                },
                {
                    label: 'Water (liters)',
                    data: water,
                    borderColor: 'rgba(255, 99, 132, 1)',
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});