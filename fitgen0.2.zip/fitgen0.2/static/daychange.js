const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const today = new Date().getDay();
document.getElementById('day-title').textContent = `🍽️ ${daysOfWeek[today === 0 ? 6 : today - 1]}'s Plan`;
console.log("Daychange loaded");
// Add functionality for day navigation if needed
document.addEventListener('DOMContentLoaded', () => {
    // Placeholder for future day navigation logic
});