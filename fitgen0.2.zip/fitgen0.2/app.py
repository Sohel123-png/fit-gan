from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import datetime
import os
import pandas as pd
import random
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'fitgen_secret')

def generate_chart(user_data):
    dates = [entry["date"] for entry in user_data]
    scores = [entry["score"] for entry in user_data]
    plt.figure(figsize=(5, 3))
    plt.plot(dates, scores, marker='o', color='purple')
    plt.title("Tera Progress Bhai!")
    plt.xlabel("Date")
    plt.ylabel("Score")
    plt.xticks(rotation=45)
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    chart_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return f"data:image/png;base64,{chart_url}"

def init_db():
    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            gender TEXT,
            diet TEXT DEFAULT 'vegetarian',
            health_condition TEXT,
            budget INTEGER DEFAULT 350,
            preferences TEXT
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS goals (
            user_id INTEGER,
            goal TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS tracker (
            user_id INTEGER,
            date TEXT,
            sleep_hours INTEGER,
            water_intake FLOAT,
            social_media FLOAT,
            score INTEGER,
            diet_adherence INTEGER,
            meal_consumed INTEGER,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS diet_cycle (
            user_id INTEGER,
            day_index INTEGER,
            meal_type TEXT,
            meal_name TEXT,
            meal_calories INTEGER,
            meal_protein INTEGER,
            completed INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS meal_plans (
            user_id INTEGER,
            period TEXT,
            day_index INTEGER,
            meal_type TEXT,
            meal_name TEXT,
            meal_calories INTEGER,
            meal_protein INTEGER,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')

        # Check if 'completed' column exists and add if not
        cursor.execute("PRAGMA table_info(diet_cycle)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'completed' not in columns:
            cursor.execute("ALTER TABLE diet_cycle ADD COLUMN completed INTEGER DEFAULT 0")
        
        conn.commit()

    # Initialize external meals database
    with sqlite3.connect('external_meals.db') as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS meals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            diet TEXT,
            budget INTEGER,
            calories INTEGER,
            goals TEXT,
            protein INTEGER,
            cooking_time INTEGER,
            allergens TEXT
        )''')
        conn.commit()

        # Populate external meals table if empty
        cursor.execute("SELECT COUNT(*) FROM meals")
        meal_count = cursor.fetchone()[0]
        if meal_count == 0:
            sample_meals = [
                ("Veg Stir Fry", "vegetarian", 10, 200, "weight_loss,general", 8, 15, ""),
                ("Lentil Soup", "vegan", 8, 180, "general,weight_loss", 10, 20, ""),
                ("Paneer Tikka", "vegetarian", 15, 250, "muscle_gain,general", 15, 25, "milk"),
                ("Quinoa Salad", "vegan", 12, 220, "weight_loss,general", 12, 10, ""),
                ("Poha", "vegetarian", 10, 150, "general,weight_loss", 5, 10, ""),
                ("Chickpea Curry", "vegan", 12, 250, "general,muscle_gain", 14, 25, ""),
                ("Vegetable Upma", "vegetarian", 10, 180, "general,weight_loss", 6, 15, ""),
                ("Tofu Scramble", "vegan", 10, 200, "weight_loss,general", 12, 15, ""),
                ("Spinach Dal", "vegan", 10, 220, "general,weight_loss", 12, 20, ""),
                ("Oatmeal with Berries", "vegetarian", 10, 160, "general,weight_loss", 6, 10, "milk"),
                ("Chickpea Salad", "vegan", 12, 200, "weight_loss,general", 10, 15, ""),
                ("Fruit Salad", "vegan", 10, 120, "weight_loss,general", 3, 5, ""),
                ("Vegetable Soup", "vegan", 8, 160, "general,weight_loss", 7, 20, ""),
                ("Masala Oats", "vegetarian", 10, 170, "general,weight_loss", 6, 15, ""),
                ("Paneer Bhurji", "vegetarian", 15, 260, "muscle_gain,general", 16, 20, "milk"),
                ("Vegan Buddha Bowl", "vegan", 12, 230, "weight_loss,general", 10, 15, "")
            ]
            cursor.executemany("INSERT OR IGNORE INTO meals (name, diet, budget, calories, goals, protein, cooking_time, allergens) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", sample_meals)
            conn.commit()
            print(f"Inserted {len(sample_meals)} sample meals into external_meals.db")

def get_meal_suggestion(diet, gender, health_condition, budget, goals, day_index, period="daily", preferences=None, last_meals=None):
    diet = diet or "vegetarian"
    goals = goals or ["general"]
    health_condition = health_condition or ""
    budget = int(budget) if budget is not None else 350
    preferences = preferences or ""
    last_meals = last_meals or []

    with sqlite3.connect('external_meals.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name, budget, calories, goals, protein, cooking_time, allergens FROM meals WHERE diet=? AND budget<=? AND (allergens IS NULL OR allergens NOT LIKE ?)",
                      (diet, budget, f"%{preferences}%"))
        meals = [{"name": row[0], "budget": row[1], "calories": row[2], "goals": row[3].split(','), "protein": row[4], "cooking_time": row[5], "allergens": row[6] or ""} for row in cursor.fetchall()]

    # Exclude last meals for variety
    available_meals = [meal for meal in meals if meal["name"] not in last_meals]
    if not available_meals:
        available_meals = meals

    # Filter by goals
    available_meals = [meal for meal in available_meals if any(goal in meal["goals"] for goal in goals) or "general" in meal["goals"]]
    if not available_meals:
        available_meals = [meal for meal in meals if "general" in meal["goals"]]

    # Health condition filters
    if "diabetes" in health_condition.lower():
        available_meals = [m for m in available_meals if m["calories"] <= 300]
    if "thyroid" in health_condition.lower() and gender == "female":
        available_meals = [m for m in available_meals if "fish" not in m["allergens"] and m["protein"] >= 10]

    if not available_meals:
        cursor.execute("SELECT name, budget, calories, goals, protein, cooking_time, allergens FROM meals WHERE diet=?", (diet,))
        available_meals = [{"name": row[0], "budget": row[1], "calories": row[2], "goals": row[3].split(','), "protein": row[4], "cooking_time": row[5], "allergens": row[6] or ""} for row in cursor.fetchall()]

    if not available_meals:
        default_plan = [
            {"meal_type": "breakfast", "meal": {"name": "Default Oatmeal", "calories": 150, "protein": 5}},
            {"meal_type": "lunch", "meal": {"name": "Default Salad", "calories": 200, "protein": 10}},
            {"meal_type": "dinner", "meal": {"name": "Default Soup", "calories": 180, "protein": 8}},
            {"meal_type": "snack", "meal": {"name": "Default Fruit", "calories": 100, "protein": 2}}
        ]
        if period == "weekly":
            return [{"day": i, "meals": default_plan} for i in range(7)]
        elif period == "monthly":
            return [{"day": i, "meals": default_plan} for i in range(30)]
        return default_plan

    if period == "daily":
        meal_types = ["breakfast", "lunch", "dinner", "snack"]
        daily_plan = []
        used_names = set(last_meals)  # Start with last meals to avoid repetition
        high_protein_added = False
        for meal_type in meal_types:
            filtered_meals = [m for m in available_meals if m["name"] not in used_names]
            if not filtered_meals:
                used_names.clear()
                filtered_meals = [m for m in available_meals if m["name"] not in last_meals]  # Reset with last meals excluded
            if not filtered_meals:
                filtered_meals = available_meals  # Fallback if no options left
            if not high_protein_added and meal_type in ["lunch", "dinner"]:
                high_protein_meals = [m for m in filtered_meals if m["protein"] >= 10]
                filtered_meals = high_protein_meals if high_protein_meals else filtered_meals
                high_protein_added = True
            meal = random.choice(filtered_meals)
            used_names.add(meal["name"])
            daily_plan.append({"meal_type": meal_type, "meal": meal})
        return daily_plan
    elif period in ["weekly", "monthly"]:
        days = 7 if period == "weekly" else 30
        plan = []
        all_used_names = set(last_meals)  # Track all used meals across days
        for day in range(days):
            day_plan = []
            used_names = set()
            high_protein_added = False
            for meal_type in ["breakfast", "lunch", "dinner", "snack"]:
                filtered_meals = [m for m in available_meals if m["name"] not in used_names and m["name"] not in all_used_names]
                if not filtered_meals:
                    used_names.clear()
                    filtered_meals = [m for m in available_meals if m["name"] not in all_used_names]
                if not filtered_meals:
                    filtered_meals = available_meals
                if not high_protein_added and meal_type in ["lunch", "dinner"]:
                    high_protein_meals = [m for m in filtered_meals if m["protein"] >= 10]
                    filtered_meals = high_protein_meals if high_protein_meals else filtered_meals
                    high_protein_added = True
                meal = random.choice(filtered_meals)
                used_names.add(meal["name"])
                all_used_names.add(meal["name"])
                day_plan.append({"meal_type": meal_type, "meal": meal})
            plan.append({"day": day, "meals": day_plan})
        return plan

def get_recipe(meal_name):
    recipes = {
        "Poha": {
            "ingredients": "50g poha (₹3), 1 onion (₹2), 1 chili (₹1), oil (₹1), lemon (₹3)",
            "instructions": "Soak poha 5 min. Heat oil, add mustard seeds, chili, onion, sauté. Add poha, salt, cook 5 min. Add lemon, serve.",
            "time": "10 min",
            "benefits": "Rich in carbs, good for energy."
        },
        "Veg Stir Fry": {
            "ingredients": "100g mixed vegetables (₹5), 1 tbsp soy sauce (₹2), 1 onion (₹2), oil (₹1), spices (₹1)",
            "instructions": "Heat oil in a pan, sauté onion until golden. Add mixed vegetables and spices, stir-fry for 10 min. Add soy sauce, cook for 2 min. Serve hot.",
            "time": "15 min",
            "benefits": "Rich in fiber and vitamins, supports weight loss."
        },
    }
    return recipes.get(meal_name, {
        "ingredients": "N/A",
        "instructions": "Check with chatbot!",
        "time": "N/A",
        "benefits": "N/A"
    })

def get_grocery_list(plan):
    ingredients = {}
    for day in plan:
        for meal in day["meals"]:
            recipe = get_recipe(meal["meal"]["name"])
            for item in recipe["ingredients"].split(", "):
                key = item.split(" (")[0].strip()
                if key in ingredients:
                    ingredients[key] += 1
                else:
                    ingredients[key] = 1
    return {k: v for k, v in ingredients.items() if v > 0}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        gender = request.form['gender']
        diet = request.form['diet']
        health_condition = request.form.get('health_condition', '')
        budget = int(request.form['budget'])
        goals = request.form.getlist('goals')
        preferences = request.form.get('preferences', '')

        if not all([username, email, password]):
            flash("All fields are required.")
            return redirect(url_for('register'))
        hashed_password = generate_password_hash(password)
        try:
            with sqlite3.connect('fitgen.db') as conn:
                cursor = conn.cursor()
                cursor.execute('INSERT INTO users (username, email, password, gender, diet, health_condition, budget, preferences) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                              (username, email, hashed_password, gender, diet, health_condition, budget, preferences))
                user_id = cursor.lastrowid
                for goal in goals:
                    cursor.execute('INSERT INTO goals (user_id, goal) VALUES (?, ?)', (user_id, goal))
                conn.commit()
            flash("Registered! Login now.")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Email already in use.")
            return redirect(url_for('register'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        try:
            with sqlite3.connect('fitgen.db') as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM users WHERE email=?', (email,))
                user = cursor.fetchone()
            if user and check_password_hash(user[3], password):
                session['user_id'] = user[0]
                session['username'] = user[1]
                return redirect(url_for('dashboard'))
            flash("Invalid login.")
        except sqlite3.Error:
            flash("Error, try again.")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out.")
    return redirect(url_for('login'))

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        flash("Login first.")
        return redirect(url_for('login'))

    if request.method == 'POST':
        if 'track' in request.form:
            sleep = int(request.form['sleep'])
            water = float(request.form['water'])
            social = float(request.form['social'])
            adherence = 1 if 'adherence' in request.form else 0
            consumed = 1 if request.form.get('consumed') == 'yes' else 0

            score = (3 if 7 <= sleep <= 9 else 2 if 5 <= sleep < 7 or 9 < sleep <= 10 else 1) + \
                    (3 if water >= 2 else 2 if 1 <= water < 2 else 1) + \
                    (4 if social < 2 else 2 if 2 <= social <= 3 else 0)

            with sqlite3.connect('fitgen.db') as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO tracker (user_id, date, sleep_hours, water_intake, social_media, score, diet_adherence, meal_consumed) VALUES (?, DATE('now'), ?, ?, ?, ?, ?, ?)",
                              (session['user_id'], sleep, water, social, score, adherence, consumed))
                conn.commit()
            return redirect(url_for('progress', score=score))

    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT diet, gender, health_condition, budget, preferences FROM users WHERE id=?", (session['user_id'],))
        user_data = cursor.fetchone()
        cursor.execute("SELECT goal FROM goals WHERE user_id=?", (session['user_id'],))
        goals = [row[0] for row in cursor.fetchall()]
        cursor.execute("SELECT meal_type, meal_name, meal_calories, meal_protein, completed FROM diet_cycle WHERE user_id=? AND day_index=?",
                      (session['user_id'], datetime.datetime.now().weekday()))
        daily_plan_db = cursor.fetchall() or []

    if not daily_plan_db:
        diet, gender, health_condition, budget, preferences = user_data
        # Fetch last day's meals to avoid repetition
        cursor.execute("SELECT meal_name FROM diet_cycle WHERE user_id=? AND day_index=?", (session['user_id'], (datetime.datetime.now().weekday() - 1) % 7))
        last_meals = [row[0] for row in cursor.fetchall()]
        daily_plan_data = get_meal_suggestion(diet, gender, health_condition, budget, goals, datetime.datetime.now().weekday(), preferences=preferences, last_meals=last_meals)
        
        daily_plan = daily_plan_data
        with sqlite3.connect('fitgen.db') as conn:
            cursor = conn.cursor()
            for meal in daily_plan:
                cursor.execute("INSERT INTO diet_cycle (user_id, day_index, meal_type, meal_name, meal_calories, meal_protein) VALUES (?, ?, ?, ?, ?, ?)",
                              (session['user_id'], datetime.datetime.now().weekday(), meal["meal_type"], meal["meal"]["name"], meal["meal"]["calories"], meal["meal"]["protein"]))
            conn.commit()
        if daily_plan_data[0]["meal"]["name"].startswith("Default"):
            flash("No meals match your criteria. Showing a default plan. Update your preferences for personalized meals.")

    daily_plan = [
        {
            "meal_type": meal[0],
            "meal": {"name": meal[1], "calories": meal[2], "protein": meal[3]},
            "completed": meal[4]
        } for meal in daily_plan_db
    ]
    grocery_list = get_grocery_list([{"meals": daily_plan}]).items()

    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT date, score FROM tracker WHERE user_id=? ORDER BY date DESC LIMIT 7", (session['user_id'],))
        user_data = [{"date": row[0], "score": row[1]} for row in cursor.fetchall()]
        chart = generate_chart(user_data) if user_data else None
        cursor.execute("SELECT AVG(score), COUNT(*) FROM tracker WHERE user_id=? AND date >= DATE('now', '-7 days')", (session['user_id'],))
        avg_score, count = cursor.fetchone()
        avg_score = avg_score or 0
        adherence = count if count else 0
        progress = f"Tune {adherence} din diet follow kiya! Score: {avg_score:.1f}. Aise hi josh mein raha!"

    return render_template('dashboard.html', username=session['username'], daily_plan=daily_plan, grocery_list=grocery_list, progress=progress, chart=chart)

@app.route('/meal_plan/<period>')
def meal_plan(period):
    if 'user_id' not in session:
        flash("Login first.")
        return redirect(url_for('login'))
    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT diet, gender, health_condition, budget, preferences FROM users WHERE id=?", (session['user_id'],))
        user_data = cursor.fetchone()
        cursor.execute("SELECT goal FROM goals WHERE user_id=?", (session['user_id'],))
        goals = [row[0] for row in cursor.fetchall()]
        cursor.execute("SELECT day_index, meal_type, meal_name, meal_calories, meal_protein FROM meal_plans WHERE user_id=? AND period=?",
                      (session['user_id'], period))
        plan_data = cursor.fetchall()

    if not plan_data:
        diet, gender, health_condition, budget, preferences = user_data
        # Fetch last plan's meals to avoid repetition
        cursor.execute("SELECT meal_name FROM meal_plans WHERE user_id=? AND period=?", (session['user_id'], period))
        last_meals = [row[0] for row in cursor.fetchall()]
        plan = get_meal_suggestion(diet, gender, health_condition, budget, goals, 0, period, preferences, last_meals)
        is_default = plan[0]["meals"][0]["meal"]["name"].startswith("Default") if period in ["weekly", "monthly"] else plan[0]["meal"]["name"].startswith("Default")
        if is_default:
            flash("No meals match your criteria for the meal plan. Showing a default plan. Update your preferences for personalized meals.")
        with sqlite3.connect('fitgen.db') as conn:
            cursor = conn.cursor()
            for day_plan in plan:
                for meal in day_plan["meals"]:
                    cursor.execute("INSERT INTO meal_plans (user_id, period, day_index, meal_type, meal_name, meal_calories, meal_protein) VALUES (?, ?, ?, ?, ?, ?, ?)",
                                  (session['user_id'], period, day_plan["day"], meal["meal_type"], meal["meal"]["name"], meal["meal"]["calories"], meal["meal"]["protein"]))
            conn.commit()
        plan_data = [(d["day"], m["meal_type"], m["meal"]["name"], m["meal"]["calories"], m["meal"]["protein"]) for d in plan for m in d["meals"]]

    return render_template('meal_plan.html', period=period, plan=plan_data, username=session['username'])

@app.route('/recipe/<meal_name>')
def recipe(meal_name):
    if 'user_id' not in session:
        flash("Login first.")
        return redirect(url_for('login'))
    recipe = get_recipe(meal_name)
    return render_template('recipe.html', meal_name=meal_name, recipe=recipe)

@app.route('/progress')
def progress():
    if 'user_id' not in session:
        flash("Login first.")
        return redirect(url_for('login'))
    
    latest_score = request.args.get('score', type=int, default=None)
    
    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT date, sleep_hours, water_intake, social_media, score, diet_adherence, meal_consumed FROM tracker WHERE user_id=? ORDER BY date DESC LIMIT 7",
                      (session['user_id'],))
        entries = cursor.fetchall()
    
    formatted_entries = [
        {
            "date": row[0],
            "sleep_hours": row[1],
            "water_intake": row[2],
            "social_media": row[3],
            "score": row[4],
            "diet_adherence": "Yes" if row[5] else "No",
            "meal_consumed": "Yes" if row[6] else "No"
        } for row in entries
    ]
    
    return render_template('progress.html', entries=formatted_entries, latest_score=latest_score)

@app.route('/progress_data')
def progress_data():
    if 'user_id' not in session:
        return jsonify({"error": "Login first!"}), 401
    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT date, sleep_hours, water_intake, social_media, score, diet_adherence, meal_consumed FROM tracker WHERE user_id=? ORDER BY date DESC LIMIT 7",
                      (session['user_id'],))
        entries = cursor.fetchall()
    formatted_entries = [
        {
            "date": row[0],
            "sleep_hours": row[1],
            "water_intake": row[2],
            "social_media": row[3],
            "score": row[4],
            "diet_adherence": row[5],
            "meal_consumed": row[6]
        } for row in entries
    ]
    return jsonify(formatted_entries)

@app.route('/chat', methods=['POST'])
def chat():
    if 'user_id' not in session:
        return jsonify({"response": "Login first!"})
    user_message = request.json.get('message', '').lower().strip()
    response = ""

    with sqlite3.connect('fitgen.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT diet, gender, health_condition, budget, preferences FROM users WHERE id=?", (session['user_id'],))
        user_data = cursor.fetchone()
        diet, gender, health_condition, budget, preferences = user_data
        cursor.execute("SELECT meal_type, meal_name, completed FROM diet_cycle WHERE user_id=? AND day_index=?",
                      (session['user_id'], datetime.datetime.now().weekday()))
        daily_plan = {row[0]: {"name": row[1], "completed": row[2]} for row in cursor.fetchall()}
        cursor.execute("SELECT COUNT(*) FROM tracker WHERE user_id=? AND diet_adherence=1 AND date >= DATE('now', '-7 days')",
                      (session['user_id'],))
        adherence = cursor.fetchone()[0]
        cursor.execute("SELECT AVG(score) FROM tracker WHERE user_id=? AND date >= DATE('now', '-7 days')", (session['user_id'],))
        avg_score = cursor.fetchone()[0] or 0

    all_completed = all(meal["completed"] for meal in daily_plan.values()) if daily_plan else False
    if all_completed:
        cursor.execute("SELECT goal FROM goals WHERE user_id=?", (session['user_id'],))
        goals = [row[0] for row in cursor.fetchall()]
        # Fetch last day's meals to avoid repetition
        cursor.execute("SELECT meal_name FROM diet_cycle WHERE user_id=? AND day_index=?", (session['user_id'], (datetime.datetime.now().weekday() - 1) % 7))
        last_meals = [row[0] for row in cursor.fetchall()]
        new_plan = get_meal_suggestion(diet, gender, health_condition, budget, goals, datetime.datetime.now().weekday(), preferences=preferences, last_meals=last_meals)
        with sqlite3.connect('fitgen.db') as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM diet_cycle WHERE user_id=? AND day_index=?", (session['user_id'], datetime.datetime.now().weekday()))
            for meal in new_plan:
                cursor.execute("INSERT INTO diet_cycle (user_id, day_index, meal_type, meal_name, meal_calories, meal_protein) VALUES (?, ?, ?, ?, ?, ?)",
                              (session['user_id'], datetime.datetime.now().weekday(), meal["meal_type"], meal["meal"]["name"], meal["meal"]["calories"], meal["meal"]["protein"]))
            conn.commit()
        daily_plan = {meal["meal_type"]: {"name": meal["meal"]["name"], "completed": 0} for meal in new_plan}
        response = "All meals completed! Here's your new plan for today: " + ", ".join([f"{k.capitalize()}: {v['name']}" for k, v in daily_plan.items()]) + ". What's next?"

    elif any(keyword in user_message for keyword in ["completed meal", "ate meal", "finished meal"]):
        for meal_type, meal in daily_plan.items():
            if meal["name"].lower() in user_message or meal_type in user_message:
                if meal["completed"]:
                    response = f"You already marked {meal['name']} ({meal_type}) as completed. Want to change it? Say 'change meal {meal_type}'."
                else:
                    with sqlite3.connect('fitgen.db') as conn:
                        cursor = conn.cursor()
                        cursor.execute("UPDATE diet_cycle SET completed=1 WHERE user_id=? AND day_index=? AND meal_type=? AND meal_name=?",
                                      (session['user_id'], datetime.datetime.now().weekday(), meal_type, meal["name"]))
                        cursor.execute("INSERT INTO tracker (user_id, date, meal_consumed) VALUES (?, DATE('now'), 1)",
                                      (session['user_id'],))
                        conn.commit()
                    daily_plan[meal_type]["completed"] = 1
                    response = f"Marked {meal['name']} ({meal_type}) as completed! "
                    if all(m["completed"] for m in daily_plan.values()):
                        new_plan = get_meal_suggestion(diet, gender, health_condition, budget, goals, datetime.datetime.now().weekday(), preferences=preferences, last_meals=[m["name"] for m in daily_plan.values()])
                        with sqlite3.connect('fitgen.db') as conn:
                            cursor = conn.cursor()
                            cursor.execute("DELETE FROM diet_cycle WHERE user_id=? AND day_index=?", (session['user_id'], datetime.datetime.now().weekday()))
                            for meal in new_plan:
                                cursor.execute("INSERT INTO diet_cycle (user_id, day_index, meal_type, meal_name, meal_calories, meal_protein) VALUES (?, ?, ?, ?, ?, ?)",
                                              (session['user_id'], datetime.datetime.now().weekday(), meal["meal_type"], meal["meal"]["name"], meal["meal"]["calories"], meal["meal"]["protein"]))
                            conn.commit()
                        daily_plan = {meal["meal_type"]: {"name": meal["meal"]["name"], "completed": 0} for meal in new_plan}
                        response += "All meals done! New plan: " + ", ".join([f"{k.capitalize()}: {v['name']}" for k, v in daily_plan.items()]) + "."
                    else:
                        response += "What's next? Say 'today's plan' or 'recipe for [meal]'."
                break
        else:
            response = "Which meal did you complete? Say something like 'completed breakfast' or 'ate Poha'."

    elif "change meal" in user_message:
        for meal_type in daily_plan:
            if meal_type in user_message:
                cursor.execute("SELECT goal FROM goals WHERE user_id=?", (session['user_id'],))
                goals = [row[0] for row in cursor.fetchall()]
                new_plan = get_meal_suggestion(diet, gender, health_condition, budget, goals, datetime.datetime.now().weekday(), preferences=preferences, last_meal=daily_plan[meal_type]["name"])
                new_meal = next((m for m in new_plan if m["meal_type"] == meal_type), None)
                if new_meal:
                    with sqlite3.connect('fitgen.db') as conn:
                        cursor = conn.cursor()
                        cursor.execute("UPDATE diet_cycle SET meal_name=?, meal_calories=?, meal_protein=?, completed=0 WHERE user_id=? AND day_index=? AND meal_type=?",
                                      (new_meal["meal"]["name"], new_meal["meal"]["calories"], new_meal["meal"]["protein"], session['user_id'], datetime.datetime.now().weekday(), meal_type))
                        conn.commit()
                    daily_plan[meal_type] = {"name": new_meal["meal"]["name"], "completed": 0}
                    response = f"Changed {meal_type} to {new_meal['meal']['name']}. Anything else? Say 'today's plan' or 'recipe for [meal]'."
                else:
                    response = f"Couldn't find a new meal for {meal_type}. Stick with {daily_plan[meal_type]['name']}? Or say 'today's plan'."
                break
        else:
            response = "Which meal to change? Say something like 'change breakfast'."

    elif any(keyword in user_message for keyword in ["meal today", "today's plan", "what to eat", "menu"]):
        response = "Aaj ka plan: " + ", ".join([f"{k.capitalize()}: {v['name']}{' (done)' if v['completed'] else ''}" for k, v in daily_plan.items()]) + ". Recipe chahiye? Bol 'recipe for [meal]' ya koi aur sawal poochh!"

    elif "recipe" in user_message or "how to make" in user_message:
        for meal_name in daily_plan.values():
            if meal_name["name"].lower() in user_message:
                recipe = get_recipe(meal_name["name"])
                response = f"**{meal_name['name']}**\nIngredients: {recipe['ingredients']}\nInstructions: {recipe['instructions']}\nTime: {recipe['time']}\nBenefits: {recipe['benefits']}\nAur kya banaye? Ya koi aur help?"
                break
        else:
            response = f"Kaunsa meal? Aaj ka plan: {', '.join(v['name'] for v in daily_plan.values())}. Bol 'recipe for [meal]' ya kuch aur poochh!"

    elif any(keyword in user_message for keyword in ["quick meal", "fast recipe", "easy food", "in a hurry"]):
        with sqlite3.connect('external_meals.db') as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name, cooking_time FROM meals WHERE diet=? AND cooking_time <= 15 AND budget <= ?", (diet, budget))
            quick_meals = cursor.fetchall()
        if quick_meals:
            meal = random.choice(quick_meals)[0]
            recipe = get_recipe(meal)
            response = f"Time kam hai? Try **{meal}** (in {recipe['time']}):\n{recipe['instructions']}\nBanake kha, aur kya plan hai aaj?"
        else:
            response = "Jaldi ka kaam: Bread + peanut butter + banana, 5 min mein ready! Aur kya chahiye?"

    elif any(keyword in user_message for keyword in ["progress", "how am i doing", "performance", "stats"]):
        response = f"Tune {adherence} din diet follow kiya! Average score: {avg_score:.1f}. Badhiya ja raha hai! Tips chahiye? Bol 'nutrition tips' ya 'exercise plan'!"

    elif any(keyword in user_message for keyword in ["grocery", "shopping list", "what to buy", "ingredients needed"]):
        with sqlite3.connect('fitgen.db') as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT meal_type, meal_name FROM diet_cycle WHERE user_id=? AND day_index=?", (session['user_id'], datetime.datetime.now().weekday()))
            daily = [{"meal_type": row[0], "meal": {"name": row[1]}} for row in cursor.fetchall()]
        grocery = get_grocery_list([{"meals": daily}])
        response = "Aaj ka grocery list:\n" + "\n".join([f"{k}: {v} qty" for k, v in grocery.items()]) + "\nBazaar ja, sab le aa! Aur kya chahiye?"

    elif any(keyword in user_message for keyword in ["nutrition", "healthy eating", "diet tips", "food advice"]):
        if "weight_loss" in user_message:
            response = "Weight loss ke liye: Kam calorie, zyada protein khao (jaise Poha, Chickpea Salad). Roz 2L pani piyo. Processed food avoid kar! Aur koi goal?"
        elif "muscle_gain" in user_message:
            response = "Muscle gain ke liye: High-protein meals (jaise Paneer Tikka). Har meal mein 20g protein target kar. Post-workout shake bhi le sakta hai! Workout bhi karta hai?"
        else:
            response = f"Teri diet ({diet}) ke liye: Balanced meals khao - carbs, protein, fats. Roz {2 if health_condition else 2.5}L pani piyo. Fruits, veggies add kar. Specific goal kya hai?"

    elif any(keyword in user_message for keyword in ["exercise", "workout", "fitness", "training"]):
        if "weight_loss" in user_message:
            response = "Weight loss ke liye: 30 min cardio (brisk walk, cycling) 5 din/week. Plus 2 din strength training (squats, push-ups). Rest bhi zaroori hai! Diet kaisa chal raha?"
        elif "muscle_gain" in user_message:
            response = "Muscle gain ke liye: 4-5 din/week weight training (bench press, squats). 8-12 reps, 3 sets. Protein shake post-workout. 7-8 hr neend le! Nutrition pe focus kiya?"
        else:
            response = "Fitness ke liye: Roz 30 min exercise - walking, yoga, ya gym. 2 din strength training kar. Stretch bhi karna, injury se bachega. Goal kya hai? Bol!"

    elif any(keyword in user_message for keyword in ["motivate", "inspiration", "encourage", "pump me up"]):
        quotes = [
            "Ek din ek kadam, tu goal tak pahunch jayega!",
            "Sweat now, shine later. Tu kar sakta hai!",
            "Har workout, har healthy meal tujhe stronger banata hai!",
            "Chhote steps bhi bade results dete hain. Keep going!"
        ]
        response = random.choice(quotes) + " Aaj kya plan hai? Bol, main help karunga!"

    elif any(keyword in user_message for keyword in ["calories", "protein", "macros"]):
        meal_name = None
        for name in daily_plan.values():
            if name["name"].lower() in user_message:
                meal_name = name["name"]
                break
        if meal_name:
            with sqlite3.connect('external_meals.db') as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT calories, protein FROM meals WHERE name=?", (meal_name,))
                result = cursor.fetchone()
                if result:
                    response = f"{meal_name} mein {result[0]} kcal aur {result[1]}g protein hai. Aur kya janna hai?"
                else:
                    response = f"{meal_name} ka data nahi mila. Default plan hai? Bol, aur kya help karu!"
        else:
            response = "Kaunsa meal? Aaj ka plan: " + ", ".join(v["name"] for v in daily_plan.values()) + ". Bol 'calories in [meal]' ya kuch aur!"

    elif any(keyword in user_message for keyword in ["health", "wellness", "feel better"]):
        response = "Health ke liye: 7-8 hr neend, balanced diet (jaise teri {diet} diet), aur roz thodi exercise. Stress kam kar - meditation try kar! Koi specific problem hai?"

    else:
        response = "Yeh kya poochh liya? 😅 Try ye: 'completed meal [meal]', 'change meal [type]', 'meal today', 'recipe for [meal]', 'quick meal', 'progress', 'grocery', 'nutrition tips', 'exercise plan', 'motivate me', ya 'calories in [meal]'."

    return jsonify({"response": response})

@app.route('/favicon.ico')
def favicon():
    return app.send_static_file('favicon.ico')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)